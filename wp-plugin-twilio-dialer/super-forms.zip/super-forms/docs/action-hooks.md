# Action Hooks:

| Hook | File(s) |
| ------ | ------ |
| `super_before_sending_email_hook` | [includes/class-ajax.php](https://github.com/RensTillmann/super-forms/search?l=PHP&q=super_before_sending_email_hook) |
| `super_before_email_success_msg_action` | [includes/class-ajax.php](https://github.com/RensTillmann/super-forms/search?l=PHP&q=super_before_email_success_msg_action) |
| `super_after_saving_contact_entry_action` | [includes/class-ajax.php](https://github.com/RensTillmann/super-forms/search?l=PHP&q=super_after_saving_contact_entry_action) |
| `super_loaded` | [super-forms.php](https://github.com/RensTillmann/super-forms/search?l=PHP&q=super_loaded) |
| `super_after_enqueue_element_scripts_action` | [super-forms.php](https://github.com/RensTillmann/super-forms/search?l=PHP&q=super_after_enqueue_element_scripts_action) |
| `before_super_init` | [super-forms.php](https://github.com/RensTillmann/super-forms/search?l=PHP&q=before_super_init) |
| `super_init` | [super-forms.php](https://github.com/RensTillmann/super-forms/search?l=PHP&q=super_init) |
| `super_before_printing_message` | [super-forms.php](https://github.com/RensTillmann/super-forms/search?l=PHP&q=super_before_printing_message) |
| `super_duplicate_form` | [super-forms.php](https://github.com/RensTillmann/super-forms/search?l=PHP&q=super_duplicate_form) |
