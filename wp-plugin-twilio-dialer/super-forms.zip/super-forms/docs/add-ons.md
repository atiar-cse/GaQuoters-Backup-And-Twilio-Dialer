# Super Forms Add-ons:

**Below a list of all add-ons that are currently available for Super Forms:**

- [WooCommerce Custom Orders Add-on](woocommerce-custom-orders-add-on)
- [Calculator Add-on](calculator-add-on)
- [Signature Add-on](signature-add-on)
- [WooCommerce Checkout Add-on](woocommerce-checkout-add-on)
- [PayPal Add-on](paypal-add-on)
- [Front-end Posting Add-on](front-end-posting-add-on)
- [Zapier Add-on](zapier-add-on)
- [MailChimp Add-on](mailchimp-add-on)
- [Mailster Add-on](mailster-add-on)
- [CSV Attachment Add-on](csv-attachment-add-on)
- [Password Protect & User Lockout & Hide Add-on](password-protect-user-lockout-hide-add-on)
- [Register & Login Add-on](register-login-add-on)
- [Popups Add-on](popups-add-on)
- [E-mail Templates Add-on](email-templates-add-on)
- [E-mail Reminders Add-on](email-reminders-add-on)
