# Radio buttons

## Features & Options

This element shares the same options as the [Checkbox](checkbox) element.
